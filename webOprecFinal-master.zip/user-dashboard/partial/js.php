		<!-- ============================================================== -->
		<!-- All Jquery -->
		<!-- ============================================================== -->
		<script src="./assets/libs/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap tether Core JavaScript -->
		<script src="./assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
		<script src="./dist/js/app-style-switcher.js"></script>
		<!--Wave Effects -->
		<script src="./dist/js/waves.js"></script>
		<!--Menu sidebar -->
		<script src="./dist/js/sidebarmenu.js"></script>
		<!--Custom JavaScript -->
		<script src="./dist/js/custom.js"></script>
		<!--This page JavaScript -->
		<!--chartis chart-->
		<script src="./assets/libs/chartist/dist/chartist.min.js"></script>
		<!-- <script src="./dist/js/pages/dashboards/dashboard1.js"></script> -->
	</body>
</html>
